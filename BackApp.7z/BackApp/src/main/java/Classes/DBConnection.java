package Classes;

import java.lang.reflect.InvocationTargetException;
import java.sql.*;

public class DBConnection {
    private String url = "jdbc:mysql://localhost:3307/mysql";
    private String user= "root";
    private String passwd= "mysql";

    public String selectCategory(){
        String OutData = null;
        try{
            Class.forName("com.mysql.cj.jdbc.Driver").getDeclaredConstructor().newInstance();
            try(Connection conn = DriverManager.getConnection(this.url, this.user, this.passwd)){
                conn.createStatement().executeUpdate("use mydatabase;");
                String sql = "select * from category where id=1;";
                try(PreparedStatement pState = conn.prepareStatement(sql)){
                    ResultSet res = pState.executeQuery();
                    if(res.next()){
                        OutData = res.getString(2);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return OutData;

    }

}
