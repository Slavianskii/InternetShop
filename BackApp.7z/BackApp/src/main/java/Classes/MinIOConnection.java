package Classes;

import io.minio.GetObjectArgs;
import io.minio.MinioClient;
import io.minio.errors.*;

import javax.imageio.ImageIO;
import javax.imageio.stream.ImageInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

public class MinIOConnection {
    private String accessKey = "minioakey";
    private String secretKey = "minioskey";
    private String endpoint = "http://localhost:9009";

    public ImageInputStream getImage(String _name){
        String OutData = null;
        MinioClient mCli = MinioClient.builder().endpoint(this.endpoint)
                .credentials(this.accessKey, this.secretKey).build();

        try(InputStream stream = mCli.getObject(GetObjectArgs.builder()
                .bucket("image").object(_name).build())) {
            BufferedReader reader = new BufferedReader(new InputStreamReader(stream));
            StringBuilder buf = new StringBuilder();
            while((OutData=reader.readLine()) != null){
                buf.append(OutData);
            }
            return ImageIO.createImageInputStream(buf);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
