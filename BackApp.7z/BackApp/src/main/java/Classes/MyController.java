package Classes;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.imageio.ImageIO;
import java.awt.*;
import java.io.IOException;

@RestController
public class MyController {
    public static class RestResponce{
        private String tmp1;
        private String tmp2;
        private Image tmp3;

        public void setTmp1(String tmp1) {
            this.tmp1 = tmp1;
        }

        public void setTmp2(String tmp2) {
            this.tmp2 = tmp2;
        }

        public void setTmp3(Image tmp3){this.tmp3 = tmp3;}
        public String getTmp1(){
            return this.tmp1;
        }
        public String getTmp2(){
            return this.tmp2;
        }
    }


    @RequestMapping(value = "/", method = RequestMethod.GET,
    produces = MediaType.APPLICATION_JSON_VALUE)
    public RestResponce restMethod(){
        RestResponce result = new RestResponce();
        DBConnection db = new DBConnection();
        MinIOConnection mIO = new MinIOConnection();
        //result.setTmp1(db.selectCategory());
        try {
            result.setTmp3(ImageIO.read(mIO.getImage("apples")));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return result;

    }
}
